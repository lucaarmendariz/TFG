import { Component } from '@angular/core';
import { AutentificadorService } from './service/autentificador.service';



@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor() {}
}
