import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-control-stock',
  templateUrl: './control-stock.page.html',
  styleUrls: ['./control-stock.page.scss'],
  
})
export class ControlStockPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
